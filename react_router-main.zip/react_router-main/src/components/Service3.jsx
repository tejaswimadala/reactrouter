// src/pages/Service3.jsx
const Service3 = () => {
  return (
    <div>
      <h3>Service 3</h3>
      <p>Description of Service 3...</p>
    </div>
  );
};

export default Service3;
