// src/pages/Service1.jsx
const Service1 = () => {
  return (
    <div>
      <h3>Service 1</h3>
      <p>Description of Service 1...</p>
    </div>
  );
};

export default Service1;
